<?php
header("Location: https://nextgame.games/public/index.php");
exit;
