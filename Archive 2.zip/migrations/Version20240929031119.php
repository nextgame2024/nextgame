<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20240929031119 extends AbstractMigration
{
    public function getDescription(): string
    {
        return '';
    }

    public function up(Schema $schema): void
    {
        // this up() migration is auto-generated, please modify it to your needs
        $this->addSql('CREATE TABLE parameters (id INT AUTO_INCREMENT NOT NULL, location_id INT NOT NULL, description VARCHAR(255) NOT NULL, value VARCHAR(255) NOT NULL, active VARCHAR(5) NOT NULL DEFAULT \'Y\', INDEX IDX_69348FE64D218E (location_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('ALTER TABLE parameters ADD CONSTRAINT FK_69348FE64D218E FOREIGN KEY (location_id) REFERENCES location (id)');
    }

    public function down(Schema $schema): void
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->addSql('ALTER TABLE parameters DROP FOREIGN KEY FK_69348FE64D218E');
        $this->addSql('DROP TABLE parameters');
    }
}
