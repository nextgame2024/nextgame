<?php

namespace App\Controller;

use App\Entity\User;
use App\Entity\Games;
use App\Form\GameFormType;
use Symfony\Component\Mime\Email;
use App\Repository\GamesRepository;
use App\Repository\TeamsRepository;
use Doctrine\ORM\EntityManagerInterface;
use App\Repository\UserProfileRepository;
use App\Repository\RatingsCentralRepository;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Mailer\MailerInterface;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Attribute\Route;
use Symfony\Component\Security\Http\Attribute\IsGranted;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\DependencyInjection\Loader\Configurator\mailer;

class DashboardRatingsCentralController extends AbstractController
{
    #[Route('/dashboard/ratings-central', name: 'app_dashboard_ratings_central')]
    #[IsGranted('IS_AUTHENTICATED_FULLY')]
    public function ratingsCentral(
        Request $request,
        RatingsCentralRepository $ratingsCentralRepository,
        UserProfileRepository $userProfile,
        MailerInterface $mailer
    ): Response {
        /** @var User $currentUser */
        $currentUser = $this->getUser();

        $currentLocation = $userProfile->findLocationsByUserId($currentUser->getId());
        $page = $request->query->getInt('page', 1);
        $limit = 25;
        $sortBy = $request->query->get('sort_by', 'g.division_id');
        $order = $request->query->get('order', 'ASC');
        $searchBy = $request->query->get('search_by_tournament', null);
        $searchValue = $request->query->get('search_value', null);
        $searchDate = $request->query->get('search_date', null);
        $isSubmitted = $request->query->get('is_submitted', null);
        $getCurrentLocation = $currentLocation[0]->getLocation();
        $location = $getCurrentLocation->getId();
        $offset = ($page - 1) * $limit;

        $paginator = $ratingsCentralRepository->findGamesByLocationId(
            $location,
            $limit,
            $offset,
            $sortBy,
            $order,
            $searchBy,
            $searchValue,
            $searchDate
        );
        $totalItems = $ratingsCentralRepository->countByTournamentRegistration(
            $location,
            $limit,
            $offset,
            $sortBy,
            $order,
            $searchBy,
            $searchValue,
            $searchDate
        );
        $totalPages = ceil($totalItems / $limit);

        if ($isSubmitted) {
            if ($isSubmitted) {
                $emailBody = "[Report]<br>
                9, \"NextGame 1.0 via Email\"<br>
                [Event]<br>
                Event fields";

                $email = (new Email())
                    ->from('generalmanager@nextgame.games')
                    ->to('jose.corredor@linqueate.com')
                    ->subject('Your Report')
                    ->html($emailBody);

                try {
                    $mailer->send($email);
                    // Optionally, you can add a success message here
                } catch (\Exception $e) {
                    // Handle the error (you can log it or set a flash message)
                    dd('Email sending failed: ' . $e->getMessage());
                }

                // dd($emailBody);
            }

            // $emailBody = "[Report]" . PHP_EOL . "9, \"NextGame 1.0 via Email\"";

            // $email = (new Email())
            //     ->from('generalmanager@nextgame.games')
            //     ->to('jose.corredor@linqueate.com')
            //     ->subject('Your Report')
            //     ->html($emailBody);

            // $mailer->send($email);
            // $name = htmlspecialchars(trim($_POST['name']), ENT_QUOTES, 'UTF-8');
            // $email = filter_var(trim($_POST['email']), FILTER_SANITIZE_EMAIL);
            // $message = htmlspecialchars(trim($emailBody), ENT_QUOTES, 'UTF-8');

            // // if (empty($name) || empty($email) || empty($message)) {
            // //     echo json_encode(["success" => false, "message" => "Please fill in all fields."]);
            // //     exit;
            // // }

            // $to = "generalmanager@nextgame.games";
            // $ccEmail = "jose.corredor@linqueate.com";
            // $subject = "New Contact Form Message from Jose";
            // $body = $message;

            // $headers = "From: $to\r\n";
            // $headers .= "Cc: $ccEmail\r\n";

            // if (mail($to, $subject, $body, $headers)) {
            //     // echo json_encode(["success" => true, "message" => "Thank you! Your message has been sent."]);
            // } else {
            //     // echo json_encode(["success" => false, "message" => "There was an error sending your message. Please try again later."]);
            // }

            // dd($emailBody);
        }

        return $this->render('dashboard/tournament_ratings_central.html.twig', [
            'tournament_games' => $paginator,
            'current_page' => $page,
            'total_pages' => $totalPages,
            'sort_by' => $sortBy,
            'order' => $order,
            'search_by' => $searchBy,
            'search_value' => $searchValue,
            'search_date' => $searchDate
        ]);
    }

    #[Route('/dashboard/create-game', name: 'app_dashboard_create_game')]
    #[IsGranted('IS_AUTHENTICATED_FULLY')]
    public function createGame(
        Request $request,
        EntityManagerInterface $entityManager,
        UserProfileRepository $userProfile
    ): Response {
        /** @var User $currentUser */
        $currentUser = $this->getUser();
        $currentLocation = $userProfile->findLocationsByUserId($currentUser->getId());

        $game = new Games();
        $userLocation = $currentLocation[0]->getLocation() ?? null;
        $form = $this->createForm(GameFormType::class, $game, [
            'user_location' => $userLocation,
        ]);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $game->setPlayerOneSet1(0);
            $game->setPlayerOneSet2(0);
            $game->setPlayerOneSet3(0);
            $game->setPlayerOneSet4(0);
            $game->setPlayerOneSet5(0);
            $game->setPlayerTwoSet1(0);
            $game->setPlayerTwoSet2(0);
            $game->setPlayerTwoSet3(0);
            $game->setPlayerTwoSet4(0);
            $game->setPlayerTwoSet5(0);
            $game->setGamesTeamOne(0);
            $game->setGamesTeamTwo(0);
            $game->setSetsTeamOne(0);
            $game->setSetsTeamTwo(0);
            $game->setIsPaid('No');
            $entityManager->persist($game);
            $entityManager->flush();

            $this->addFlash('success', 'The match has been successfully created!');

            return $this->redirectToRoute('app_dashboard_games');
        }

        return $this->render('dashboard/create_game.html.twig', [
            'form' => $form->createView(),
            'isEdit' => false,
        ]);
    }

    #[Route('/dashboard/edit-game/{id}', name: 'app_dashboard_edit_game')]
    #[IsGranted('IS_AUTHENTICATED_FULLY')]
    public function editGame(
        int $id,
        Request $request,
        EntityManagerInterface $entityManager,
        UserProfileRepository $userProfile
    ): Response {
        /** @var User $currentUser */
        $currentUser = $this->getUser();
        $currentLocation = $userProfile->findLocationsByUserId($currentUser->getId());
        $userLocation = $currentLocation[0]->getLocation() ?? null;

        $game = $entityManager->getRepository(Games::class)->find($id);

        if (!$game) {
            throw $this->createNotFoundException('User not found.');
        }

        $form = $this->createForm(GameFormType::class, $game, [
            'user_location' => $userLocation,
        ]);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $entityManager->persist($game);
            $entityManager->flush();

            $this->addFlash('success', 'The match has been successfully updated!');

            return $this->redirectToRoute('app_dashboard_games');
        }

        return $this->render('dashboard/create_game.html.twig', [
            'form' => $form->createView(),
            'isEdit' => true,
        ]);
    }

    #[Route('/dashboard/registration/payment-change/{id}', name: 'app_dashboard_payment_change', methods: ['POST'])]
    #[IsGranted('IS_AUTHENTICATED_FULLY')]
    public function paymentChange(
        int $id,
        Request $request,
        GamesRepository $gamesRepository,
        EntityManagerInterface $entityManager
    ): Response {
        $payment = $gamesRepository->find($id);

        if (!$payment) {
            throw $this->createNotFoundException('Payment not found');
        }

        $is_paid = $request->request->get('new_team_id');
        $payment->setIsPaid($is_paid);
        $entityManager->flush();

        $this->addFlash('success', 'Payment has been successfully updated!');

        return $this->redirectToRoute('app_dashboard_games');
    }
}
